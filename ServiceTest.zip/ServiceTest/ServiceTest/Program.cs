﻿using System;
using System.ServiceProcess;

namespace ServiceTest
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var service = new ReadApplication())
            {
                ServiceBase.Run(service);
                //service.OnDebug();
            }
        }
    }
}
